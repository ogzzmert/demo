﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class Creator : MonoBehaviour
{
    // Creator is responsible of building game components dynamically

    public static bool isMobile = false;
    static bool worldReady = false;
    static gameMode game_mode = gameMode.menu;
    TouchHandler handler;
    public static Transform main_camera;

    static GameObject resource_playerbase, resource_targetbase;
    static GameObject resource_stage_paint, resource_gui_paint;
    static GameObject resource_stage_menu, resource_gui_menu;
    static GameObject resource_stage_replay, resource_gui_replay;
    public static Texture2D resource_paintbrush;
    static Dictionary<int, GameObject> resource_gui;
    static Dictionary<int, GameObject> resource_stage;

    static StageManager current_stage;
    static PlayerManager current_player;
    static GuiManager current_gui;

    public static string latest_rank = "";
    public static int latest_time = 0;
    public static int latest_canvas_percent = 0;
    public static Texture2D latest_canvas;
    
    void Awake()
    {
        // initialize and load common resources from file system to memory
        int height = 1280;
        int width = 720;

        resource_playerbase = Resources.Load("character/Playerdoll") as GameObject;
        resource_targetbase = Resources.Load("character/Targetdoll") as GameObject;
        resource_gui_paint = Resources.Load("gui/PAINT_GUI") as GameObject;
        resource_stage_paint = Resources.Load("level/PAINT") as GameObject;
        resource_gui_menu = Resources.Load("gui/MENU_GUI") as GameObject;
        resource_stage_menu = Resources.Load("level/MENU") as GameObject;
        resource_gui_replay = Resources.Load("gui/REPLAY_GUI") as GameObject;
        resource_stage_replay = Resources.Load("level/REPLAY") as GameObject;
        resource_paintbrush = Resources.Load("textures/brush") as Texture2D;
        resource_gui = new Dictionary<int, GameObject>(); 
        resource_stage = new Dictionary<int, GameObject>();

        loadResource(resource_gui, "gui/", "GUI_");
        loadResource(resource_stage, "level/", "STAGE_");

        EffectHandler.build(this);
        //settings
        if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer) isMobile = true;
        float ratio = Screen.width / Screen.height;
        if (!isMobile) ratio = 1.77f;
        else
        {
            if (ratio > 2f) width = 620;
            else if (ratio >= 1.7f) width = 720;
            else if (ratio >= 1.6f) width = 800;
            else if (ratio >= 1.3f) width = 960;
        }

        if(isMobile) Screen.SetResolution(width, height, true);
        else
        {
            Screen.SetResolution(width/4 * 3, height/4 * 3, false);
            Screen.fullScreen = false;
        }
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        QualitySettings.vSyncCount = 0;
        QualitySettings.antiAliasing = 0;
        QualitySettings.anisotropicFiltering = AnisotropicFiltering.Disable;
        Application.targetFrameRate = 60;
        Input.multiTouchEnabled = true;

        handler = new TouchHandler(this);
    }
    void loadResource(Dictionary<int, GameObject> list, string path, string prefix)
    {
        int counter = 0;
        bool stop = false;
        while (!stop)
        {
            string filename = prefix + counter.ToString();
            var list_file = Resources.Load(path + filename);
            if (list_file != null) list.Add(counter, list_file as GameObject);
            else stop = true;
            counter++;
        }
    }
    void Start()
    {
        Menu();
    }
    public void Menu()
    {
        destroyWorld();

        current_stage = spawn(resource_stage_menu).AddComponent<StageManager>();
        current_gui = spawn(resource_gui_menu).AddComponent<GuiManager>();

        current_gui.GetComponent<GuiManager>().build(this);
        current_gui.gameObject.AddComponent<MenuHandler>().build(this);

        game_mode = gameMode.menu;
        worldReady = true;
    }
    public void Stage(int stage_id)
    {
        destroyWorld();

        current_stage = spawn(resource_stage[stage_id]).AddComponent<StageManager>();
        current_player = spawn(resource_playerbase).AddComponent<PlayerManager>();
        current_gui = spawn(resource_gui[0]).AddComponent<GuiManager>();

        current_stage.GetComponent<StageManager>().build(this);
        current_player.GetComponent<PlayerManager>().build(this);
        current_gui.GetComponent<GuiManager>().build(this);

        main_camera = current_player.getCamera();
        worldReady = true;
    }
    public void paintStage()
    {
        destroyWorld();

        current_stage = spawn(resource_stage_paint).AddComponent<StageManager>();
        current_gui = spawn(resource_gui_paint).AddComponent<GuiManager>();

        current_gui.GetComponent<GuiManager>().build(this);
        current_gui.transform.GetChild(0).GetChild(0)
            .gameObject.GetComponent<PaintHandler>().build(this);

        game_mode = gameMode.paint;
        worldReady = true;
    }
    public void endStage()
    {
        destroyWorld();

        current_stage = spawn(resource_stage_replay).AddComponent<StageManager>();
        current_gui = spawn(resource_gui_replay).AddComponent<GuiManager>();

        current_gui.GetComponent<GuiManager>().build(this);
        current_gui.gameObject.AddComponent<ReplayHandler>().build(this);

        game_mode = gameMode.replay;
        worldReady = true;
    }
    public GameObject spawn(GameObject prefab)
    {
        GameObject temp = Instantiate(prefab);
        temp.transform.SetParent(this.gameObject.transform);
        return temp;
    }
    public TargetManager generate_target(Transform spawnpoint)
    {
        GameObject target = Instantiate(resource_targetbase);
        target.transform.SetParent(spawnpoint);
        return target.AddComponent<TargetManager>();
    }
    void destroyWorld()
    {
        worldReady = false;
        List<GameObject> toDestroy = new List<GameObject>();
        for(int i=0; i<this.gameObject.transform.childCount; i++)
        {
            toDestroy.Add(this.gameObject.transform.GetChild(i).gameObject);
        }
        foreach(GameObject destoryable in toDestroy)
        {
            Destroy(destoryable);
        }
    }
    public void destroyThis(GameObject obj)
    {
        if (obj != null) Destroy(obj);
    }
    public static bool isWorldReady()
    {
        return worldReady;
    }
    public void set_gameMode(gameMode mode)
    {
        game_mode = mode;
    }
    public gameMode mode()
    {
        return game_mode;
    }
    void Update()
    {
        if(worldReady)
            handler.touch_analyze();
    }
    public GuiManager getGUI()
    {
        return current_gui;
    }
    public StageManager getStage()
    {
        return current_stage;
    }
    public PlayerManager getPlayer()
    {
        return current_player;
    }
    public TouchHandler getHandler()
    {
        return handler;
    }
    public SpriteRenderer getCanvas()
    {
        if (game_mode == gameMode.paint)
        {
            return current_stage.transform.GetChild(1).gameObject.GetComponent<SpriteRenderer>();
        }
        else return null;
    }
    public enum gameMode
    {
        menu = 0,
        runner = 1,
        paint = 2,
        replay = 3
    }
    public float rand(float start, float end)
    {
        return UnityEngine.Random.Range(start, end);
    }
    public static float angle(float x1, float y1, float x2, float y2)
    {
        return (float)Math.Atan2(y2 - y1, x2 - x1) * 57.2958f;
    }
    public static void transfer_bones(Transform bone1, Transform bone2)
    {
        List<Transform> bones1 = new List<Transform>();
        List<Transform> bones2 = new List<Transform>();
        foreach (Transform child in bone1.GetComponentsInChildren<Transform>()) bones1.Add(child);        
        foreach (Transform child in bone2.GetComponentsInChildren<Transform>()) bones2.Add(child);
        for(int i = 0; i < bones1.Count; i++)
        {
            bones2[i].localPosition = bones1[i].localPosition;
            bones2[i].localEulerAngles = bones1[i].localEulerAngles;
        }
        
    }
}
