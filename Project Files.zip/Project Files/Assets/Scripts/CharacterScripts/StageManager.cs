﻿using UnityEngine;
using System.Collections;
using System;
public class StageManager : MonoBehaviour
{
    // Stage Manager is responsible of starting and ending stage runner game mode
    Creator creator;
    TargetManager[] targets;
    Waypoint[] waypoints;
    Transform playerspawn;

    DateTime stage_timer;
    int total_count = 0;
    string position_string = "";
    public void build(Creator creator)
    {
        this.creator = creator;
        Physics.gravity = new Vector3(0, -12, 0);
        StartCoroutine(launch());
    }
    IEnumerator launch()
    {
        generate_targets();
        yield return new WaitUntil(() => Creator.isWorldReady());
        StartCoroutine(checker());

        StartCoroutine(runStage());
    }
    public void finishStage()
    {
        StartCoroutine(finishStage_iterator());
    }
    IEnumerator finishStage_iterator()
    {
        // ranking etc.
        creator.getPlayer().disable();
        
        creator.getGUI().throw_warning(GuiManager.warning.finish, 2.5f, 2, 2);
        yield return new WaitForSeconds(1f);
        Creator.latest_rank = position_string;
        Creator.latest_time = (int)(DateTime.Now - stage_timer).TotalSeconds;
        creator.paintStage();
    }
    void generate_targets()
    {
        Transform pointlist = this.gameObject.transform.GetChild(1).GetChild(1);
        waypoints = new Waypoint[pointlist.childCount];
        for (int i = 0; i < waypoints.Length; i++)
            waypoints[i] = pointlist.GetChild(i).gameObject.GetComponent<Waypoint>();

        Transform spawnlist = this.gameObject.transform.GetChild(1).GetChild(0);

        creator.getPlayer().gameObject.transform.SetParent(spawnlist.GetChild(0));
        spawnlist.GetChild(0).GetChild(0).localPosition = Vector3.zero;
        playerspawn = spawnlist.GetChild(0);

        targets = new TargetManager[spawnlist.childCount - 1];
        for (int i=1; i < spawnlist.childCount; i++)
        {
            targets[i - 1] = creator.generate_target(spawnlist.GetChild(i));
            targets[i - 1].build(creator, waypoints);
            
            spawnlist.GetChild(i).GetChild(0).localPosition = Vector3.zero;
        }
        total_count = spawnlist.childCount;
    }
    IEnumerator runStage()
    {
        creator.getGUI().throw_warning(GuiManager.warning.to_move, 2.5f);
        yield return new WaitForSeconds(2.5f);
        creator.getGUI().throw_warning(GuiManager.warning.to_jump, 2.5f);
        creator.getGUI().throw_warning(GuiManager.warning.sec_3, 3f, 2, 3);
        yield return new WaitForSeconds(1.5f);
        creator.getGUI().throw_warning(GuiManager.warning.sec_2, 3f, 2, 3);
        yield return new WaitForSeconds(1.5f);
        creator.getGUI().throw_warning(GuiManager.warning.sec_1, 3f, 2, 3);
        yield return new WaitForSeconds(1.5f);
        creator.getGUI().throw_warning(GuiManager.warning.go, 2f, 2, 3);
        yield return new WaitForSeconds(0.5f);
        creator.set_gameMode(Creator.gameMode.runner);
        stage_timer = DateTime.Now;
    }
    IEnumerator checker()
    {
        while(Creator.isWorldReady())
        {
            //temporary ranking system, really bad change later
            int position = total_count;
            float player = creator.getPlayer().getPosition().z;
            foreach(TargetManager t in targets)
            {
                if (t != null)
                {
                    if (t.getPosition().z < player) position--;
                }
            }

            string suffix = "th";
            if (position == 1) suffix = "st";
            else if (position == 2) suffix = "nd";
            else if (position == 3) suffix = "rd";

            position_string = position.ToString() + suffix;
            creator.getGUI().set_bar(position_string + "/" + total_count);
            yield return new WaitForSeconds(0.25f);
        }
    }
}
