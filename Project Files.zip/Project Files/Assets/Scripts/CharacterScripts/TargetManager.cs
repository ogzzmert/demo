﻿using UnityEngine;
using System.Collections;
public class TargetManager : MonoBehaviour
{
    // Target Manager is responsible of pathfinding
    Creator creator;
    CharacterController control;
    ModelManager model;
    Waypoint[] waypoints;
    Waypoint current;

    RagdollHandler ragdoll;

    int next_waypoint = 0;

    Vector3 direction;
    float accel = 0f;
    bool focus = false; 
    float stupidity = 0f;

    float offset_x = 0f;
    float offset_z = 0f;

    float min_stupid = 1f;
    float max_stupid = 5f;

    bool is_ragdoll = false;
    bool is_dead = false;
    public void build(Creator creator, Waypoint[] waypoints)
    {
        this.creator = creator;
        this.waypoints = waypoints;
        direction = Vector3.zero;
        stupidity = creator.rand(min_stupid, max_stupid);
        offset_x = creator.rand(-stupidity, stupidity);
        offset_z = creator.rand(-stupidity, stupidity);
        control = this.gameObject.transform.GetChild(0).gameObject.GetComponent<CharacterController>();
        model = this.gameObject.transform.GetChild(0).GetChild(0).gameObject.GetComponent<ModelManager>();
        ragdoll = this.gameObject.transform.GetChild(0).GetChild(2).gameObject.GetComponent<RagdollHandler>();
        model.build(creator);
        ragdoll.build(creator, control);
        StartCoroutine(pathfind());
    }
    IEnumerator pathfind()
    {
        yield return new WaitUntil(() => creator.mode() == Creator.gameMode.runner && Creator.isWorldReady());
        Vector3 pose1 = Vector3.zero;
        Vector3 pose2 = Vector3.zero;
        while (creator.mode() == Creator.gameMode.runner)
        {
            pose1 = control.transform.position;
            generate_waypoint();
            yield return new WaitForSeconds(0.33f);
            pose2 = control.transform.position;
            check_waypoint();

            if(!is_ragdoll && control.enabled)
            {
                if (Vector3.Distance(pose1, pose2) < 0.5f && next_waypoint > 0)
                {
                    set_jump(); // if stuck, jump 
                    pose1 = control.transform.position;
                    yield return new WaitForSeconds(0.33f);
                    pose2 = control.transform.position;
                    if (Vector3.Distance(pose1, pose2) < 0.5f && next_waypoint > 0) next_waypoint--; // if still stuck, go back
                }
            }

        }
    }
    void generate_waypoint()
    {
        // generate a waypoint based on placed waypoints, but add stupidity factor on
        // both position and direction angle
        if (next_waypoint < waypoints.Length && !model.is_jumping && !focus && !is_ragdoll)
        {
            current = waypoints[next_waypoint];
            Vector3 c_pose = current.get_pose(stupidity);
            if (current.waypoint == Waypoint.point.normal)
            {
                c_pose = new Vector3(c_pose.x + offset_x * 0.25f, 0, c_pose.z + offset_z * 0.25f);
            }
            else if (current.waypoint == Waypoint.point.narrow)
            {
                c_pose = new Vector3(c_pose.x + creator.rand(-0.8f, 1.2f), 0, c_pose.z + creator.rand(-0.8f, 1.2f));
            }
            c_pose = (c_pose - control.transform.position);
            c_pose = Quaternion.AngleAxis(creator.rand(-stupidity, stupidity) * 0.33f, Vector3.up) * c_pose;
            direction = new Vector3(c_pose.x, 0, c_pose.z).normalized;
        }

    }
    void check_waypoint()
    {
        // check if reached generated waypoint, suffle offset by stupidity
        // and move on to the next waypoint
        if (current != null && next_waypoint < waypoints.Length)
        {
            float dist = Vector3.Distance(current.get_pose(stupidity), control.transform.position);
            if (dist < current.radius)
            {
                StartCoroutine(analyze());
                offset_x = creator.rand(-stupidity, stupidity); ;
                offset_z = creator.rand(-stupidity, stupidity); ;
                next_waypoint++;
            }
        }
    }
    IEnumerator analyze()
    {
        // check if waypoint has special operations that is needed to be done
        Waypoint.point w = current.waypoint;

        if (w == Waypoint.point.jump)
        {
            yield return new WaitForSeconds(creator.rand(0.2f, 0.4f));
            if(current != null) set_jump();
        }
    }
    void set_jump()
    {
        // try jumping if possible
        if(control.isGrounded && !is_ragdoll)
        {
            bool jump_accepted = model.try_jump();
            if (jump_accepted) StartCoroutine(model.jump_iterator(control));
        }
    }
    public void walk_away(Transform obj)
    {
        focus = true;
        StartCoroutine(walk_away_iterator(obj));
    }
    IEnumerator walk_away_iterator(Transform obj)
    {
        Vector3 old_direction = direction;
        while (focus)
        {
            // old direction is towards waypoint, walk away direction is towards negative object position
            // so direction = old direction + negative object direction, kinda generates walking away effect
            direction = ((control.transform.position - obj.position).normalized + old_direction * creator.rand(0.75f, stupidity / 2f)).normalized;
            yield return new WaitForSeconds(0.25f);
            float distance = Vector3.Distance(obj.position, control.transform.position);
            if (distance > 7.5f) break;
        }

        focus = false;
    }
    public void jump_over(Vector3 position)
    {
        set_jump();
    }
    public void push(Vector3 direction, float speed)
    {
        move(direction * speed * Time.deltaTime);
    }
    private void move(Vector3 value)
    {
        if (control.enabled && !is_ragdoll) control.Move(value);
    }
    public void finish()
    {
        // maybe do something fancy here other than destroying the object
        Debug.Log("Finish");
        Destroy(this.gameObject);
    }
    void Update()
    {
        if (!is_ragdoll)
        {
            // move towards direction and slowy rotate the model towards it
            move(direction * accel * Time.deltaTime);
            if (direction != Vector3.zero)
            {
                float angle = 270 - Creator.angle(direction.x, direction.z, model.transform.localEulerAngles.x, model.transform.localEulerAngles.z);
                model.turn_slow(Quaternion.Euler(0, angle, 0));
            }
        }

        if (!model.is_jumping && !is_ragdoll)
        {
            // increase acceleration over time, keep moving model while not jumping to fake out the gravity
            // set idle or walk animations depending on acceleration
            if (accel < 10f && direction != Vector3.zero) accel += 0.25f;
            if (accel > 1f && model.is_idle) model.try_idle(false);
            else if (accel <= 1f && !model.is_idle) model.try_idle(true);
            move(transform.up * -25f * Time.deltaTime);
        }
    }

    public void hit(bool deadly, float stun_time, Transform interactable)
    {
        EffectHandler.cast_effect(control.transform, EffectHandler.effect.hit);
        StartCoroutine(hit_iterator(deadly, stun_time, interactable));
    }
    IEnumerator hit_iterator(bool deadly, float stun_time, Transform interactable)
    {
        // first, copy animation bones to ragdoll bones
        // then deactivate animation model and active ragdoll model
        // do the ragdoll for a while (stun_time) and
        // set ragdoll bones to animation bones, slowly
        // after a while, deactivate ragdoll model and activate animation model
         
        if (!is_ragdoll && !is_dead && stun_time > 0)
        {
            is_ragdoll = true;
            control.enabled = false;
            model.activate(false);
            Creator.transfer_bones(model.get_bone(), ragdoll.get_bone());
            ragdoll.gameObject.SetActive(true);
            StartCoroutine(ragdoll.turn_on(interactable));

            yield return new WaitForSeconds(stun_time);

            StartCoroutine(ragdoll.turn_off());
            ragdoll.gameObject.SetActive(false);
            Creator.transfer_bones(ragdoll.get_bone(), model.get_bone());
            model.gameObject.SetActive(true);
            control.enabled = true;
            if (!deadly)
            {
                EffectHandler.cast_effect(control.transform, EffectHandler.effect.grounded);
                for (int i = 0; i < 30; i++)
                {
                    model.translate_wakeup();
                    control.Move(transform.up * -25f * Time.deltaTime);
                    yield return new WaitForSeconds(0.015f);
                }
            }
            else model.gameObject.transform.GetChild(0).gameObject.SetActive(false);
            model.activate(true);
            is_ragdoll = false;
            if (model.is_jumping) model.set_jump_off();
            model.try_idle(false);
        }
        if (deadly) kill();
    }
    public void kill()
    {
        if(!is_dead) StartCoroutine(kill_iterator());
    }
    IEnumerator kill_iterator()
    {
        is_dead = true;
        yield return new WaitUntil(() => !is_ragdoll);
        control.enabled = false;
        control.gameObject.transform.localPosition = Vector3.zero;
        this.gameObject.transform.eulerAngles = Vector3.zero;
        next_waypoint = 0;
        accel = 0;
        model.set_jump_off();
        direction = Vector3.zero;
        current = null;
        focus = false;
        stupidity = creator.rand(min_stupid, max_stupid);
        offset_x = creator.rand(-stupidity, stupidity);
        offset_z = creator.rand(-stupidity, stupidity);
        model.gameObject.transform.GetChild(0).gameObject.SetActive(true);
        control.enabled = true;
        is_dead = false;
    }
    public Vector3 getPosition()
    {
        return control.transform.position;
    }
}
