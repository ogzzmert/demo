﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerManager : MonoBehaviour
{
    // Player Manager is responsible of calculating results of user's environmental interactions
    Creator creator;

    CharacterController control;
    ModelManager model;
    Transform cam;

    RagdollHandler ragdoll;

    float cam_rot_rate = 0.01f;
    bool is_grounded = true;

    bool is_dead = false;
    bool is_ragdoll = false;
    public void build(Creator creator)
    {
        this.creator = creator;

        control = this.gameObject.transform.GetChild(0).gameObject.GetComponent<CharacterController>();
        model = this.gameObject.transform.GetChild(0).GetChild(0).gameObject.GetComponent<ModelManager>();
        cam = this.gameObject.transform.GetChild(0).GetChild(1);
        ragdoll = this.gameObject.transform.GetChild(0).GetChild(2).gameObject.GetComponent<RagdollHandler>();
        model.build(this.creator);
        ragdoll.build(this.creator, control);
        StartCoroutine(check_player());
    }
    IEnumerator check_player()
    {
        // since there is no gravity(y = +-0),
        // straight platforms fail on isGrounded sometimes,
        // so use this checker to ensure whether controller is grounded
        // also walk/idle animations are decided only here,
        // by checking positional difference between 50 milliseconds of time
        Vector3 pose_1;
        Vector3 pose_2;
        yield return new WaitUntil(() => Creator.isWorldReady());
        while (Creator.isWorldReady())
        {
            pose_1 = control.transform.position;
            yield return new WaitForSeconds(0.05f);
            pose_2 = control.transform.position;
            if (!is_ragdoll)
            {
                if (pose_1 == pose_2 && !model.is_idle || !creator.getHandler().isMoving()) set_idle(true);
                else if (pose_1 != pose_2 && model.is_idle) set_idle(false);

                if (pose_1.y == pose_2.y || control.isGrounded) is_grounded = true;
                else is_grounded = false;
            }
            else is_grounded = false;
        }
    }
    void Update()
    {
        if (!model.is_jumping)
        {
            // if not jumping, turn camera slowly
            int dist = (int)model.control.localEulerAngles.y - (int)cam.localEulerAngles.y;
            if (dist != 0)
            {
                cam.rotation = Quaternion.Lerp(cam.rotation, model.control.rotation, cam_rot_rate);
            }
        }
        // fake gravity when isn't grounded or not jumping (cus jump already has fake gravity)
        if (!model.is_jumping && control.enabled) move(transform.up * -25f * Time.deltaTime); 
    }
    public void move(Vector3 base_pose, Vector3 current_pose, float acceleration)
    {
        // turn model to direction, move controller towards direction, both turns are based on camera direction
        float dist = Vector3.Distance(base_pose, current_pose);
        if (dist > 50f && control.enabled)
        {
            model.turn(90 - Creator.angle(base_pose.x, base_pose.y, current_pose.x, current_pose.y) + cam.localEulerAngles.y);

            // first get 2D direction vector, then cast it to 3D and combine with camera angle
            Vector3 dir = (current_pose - base_pose).normalized;
            dir = Quaternion.Euler(0, cam.localEulerAngles.y, 0) * new Vector3(dir.x, 0, dir.y);
            move(dir * acceleration * Time.deltaTime);
        }
    }
    public void push(Vector3 direction, float speed)
    {
        if(control.enabled)
            move(direction * speed * Time.deltaTime);
    }
    private void move(Vector3 value)
    {
        if (control.enabled && !is_ragdoll) control.Move(value);
    }
    public void set_idle(bool idling)
    {
        if(!is_ragdoll) model.try_idle(idling);
    }
    public void set_jump()
    {
        if (is_grounded && !is_ragdoll)
        {
            bool jump_accepted = model.try_jump();
            if(jump_accepted) StartCoroutine(model.jump_iterator(control));
        }
    }
    public void hit(bool deadly, float stun_time, Transform interactable)
    {
        EffectHandler.cast_effect(control.transform, EffectHandler.effect.hit);
        StartCoroutine(hit_iterator(deadly, stun_time, interactable));
    }
    IEnumerator hit_iterator(bool deadly, float stun_time, Transform interactable)
    {
        // first, copy animation bones to ragdoll bones
        // then deactivate animation model and active ragdoll model
        // do the ragdoll for a while (stun_time) and
        // set ragdoll bones to animation bones, slowly
        // after a while, deactivate ragdoll model and activate animation model

        if (!is_dead && !is_ragdoll && stun_time > 0)
        {
            is_ragdoll = true;
            control.enabled = false;
            model.activate(false);
            Creator.transfer_bones(model.get_bone(), ragdoll.get_bone());
            ragdoll.gameObject.SetActive(true);
            StartCoroutine(ragdoll.turn_on(interactable));

            yield return new WaitForSeconds(stun_time);

            StartCoroutine(ragdoll.turn_off());
            ragdoll.gameObject.SetActive(false);
            Creator.transfer_bones(ragdoll.get_bone(), model.get_bone());
            model.gameObject.SetActive(true);
            control.enabled = true;
            if (!deadly)
            {
                EffectHandler.cast_effect(control.transform, EffectHandler.effect.grounded);
                for (int i = 0; i < 30; i++)
                {
                    model.translate_wakeup();
                    control.Move(transform.up * -25f * Time.deltaTime);
                    yield return new WaitForSeconds(0.015f);
                }
            }
            model.activate(true);
            is_ragdoll = false;
            set_idle(true);
        }
        if (deadly) kill();
    }
    public void kill()
    {
        if (!is_dead)
        {
            StartCoroutine(kill_iterator());
            creator.getHandler().reset();
        }
    }
    IEnumerator kill_iterator()
    {
        is_dead = true;
        yield return new WaitUntil(() => !is_ragdoll);
        control.enabled = false;
        this.control.gameObject.transform.localPosition = Vector3.zero;
        this.control.gameObject.transform.localEulerAngles = Vector3.zero;
        cam.transform.localEulerAngles = Vector3.zero;
        model.turn(0);
        if(model.is_jumping) model.set_jump_off();
        set_idle(true);
        yield return new WaitForSeconds(0.1f);
        control.enabled = true;
        is_dead = false;
    }
    public Vector3 getPosition()
    {
        return control.transform.position;
    }
    public Transform getCamera()
    {
        return cam;
    }
    public void disable()
    {
        control.enabled = false;
        model.transform.GetChild(0).gameObject.SetActive(false);
    }
}
