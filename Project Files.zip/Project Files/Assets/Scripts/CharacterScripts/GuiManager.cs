﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
public class GuiManager : MonoBehaviour
{
    // GUI Manager is responsible of managing visuals over the screen
    Creator creator;
    GameObject base_txt;
    List<Sprite> texts;
    public void build(Creator creator)
    {
        this.creator = creator;
        set_bar(null);
        loadTexts();
    }
    void loadTexts()
    {
        base_txt = Resources.Load("gui/Sprites/sprite") as GameObject;
        texts = new List<Sprite>();
        int counter = 0;
        bool stop = false;
        while (!stop)
        {
            string filename = "tex_" + counter.ToString();
            var list_file = Resources.Load<Sprite>("textures/" + filename);
            if (list_file != null) texts.Add(list_file as Sprite);
            else stop = true;
            counter++;
        }
    }
    public void throw_warning(warning warning_text, float time=3f, int show_type=1, int scale=1)
    {
        StartCoroutine(throw_warning_iterator(warning_text, time, show_type, scale));
    }
    IEnumerator throw_warning_iterator(warning warning_text, float time, int show_type, int scale)
    {
        Sprite txt = texts[(int)warning_text];
        GameObject sprite = creator.spawn(base_txt);
        sprite.transform.SetParent(transform.GetChild(5).GetChild(scale - 1));
        sprite.transform.localPosition = Vector3.zero;
        sprite.transform.localScale = new Vector3(1,1, 1);

        Image visual = sprite.gameObject.GetComponent<Image>();
        visual.sprite = txt;
        visual.rectTransform.sizeDelta = new Vector2(txt.texture.width, txt.texture.height);
        Color c = new Color(1,1,1,1);
        float width_factor = txt.texture.width / 100f;
        float height_factor = txt.texture.height / 100f;
        float time_factor = 0.015f;
        if (show_type == 1)
        {
            width_factor /= 2f;
            height_factor /= 2f;

            for(int i = 0; i < (int)time; i++)
            {
                for(int j = 0; j < 25; j++)
                {
                    visual.rectTransform.sizeDelta = new Vector2(visual.rectTransform.sizeDelta.x + width_factor,
                        visual.rectTransform.sizeDelta.y + height_factor);

                    yield return new WaitForSeconds(time_factor);
                }
                for (int j = 0; j < 25; j++)
                {
                    visual.rectTransform.sizeDelta = new Vector2(visual.rectTransform.sizeDelta.x - width_factor,
                        visual.rectTransform.sizeDelta.y - height_factor);

                    yield return new WaitForSeconds(time_factor);
                }
            }
        }
        else if (show_type == 2)
        {
            for (int i = 0; i < 30 * (int)time; i++)
            {
                c.a -= time_factor;
                visual.color = c;
                visual.rectTransform.sizeDelta = new Vector2(visual.rectTransform.sizeDelta.x - width_factor,
                    visual.rectTransform.sizeDelta.y - height_factor);

                yield return new WaitForSeconds(0.015f);  
            }
        }
        creator.destroyThis(sprite);
    }
    public void set_bar(string text)
    {
        gameObject.transform.GetChild(1).GetChild(0).GetChild(0).gameObject.GetComponent<Text>().text = text;
    }
    public enum warning
    {
        to_move = 0, 
        to_jump = 1,
        to_paint = 2,
        sec_3 = 3,
        sec_2 = 4,
        sec_1 = 5,
        go = 6,
        finish = 7,
        praise_1 = 8,
        praise_2 = 9,
        praise_3 = 10
    }
}
