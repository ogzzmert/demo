﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModelManager : MonoBehaviour
{
    // Model Manager is responsible of playing humanoid animations and effects
    Creator creator;
    Animator animator;
    public Transform control;

    List<Vector3> original_pos = new List<Vector3>();
    List<Quaternion> original_rot = new List<Quaternion>();
    Transform bone;

    public bool is_idle = true;
    public bool is_jumping = false;
    public void build(Creator creator)
    {
        this.creator = creator;
        animator = this.gameObject.GetComponent<Animator>();
        control = this.gameObject.transform;
        bone = this.gameObject.transform.GetChild(1);
        foreach (Transform child in bone.GetComponentsInChildren<Transform>()) original_rot.Add(child.localRotation);
        foreach (Transform child in bone.GetComponentsInChildren<Transform>()) original_pos.Add(child.localPosition);
    }
    public void activate(bool on)
    {
        this.gameObject.GetComponent<SphereCollider>().enabled = on;
        animator.enabled = on;
        this.gameObject.SetActive(on);
        if (on) animator.SetTrigger("Reset");
    }
    public void turn(float angle)
    {
        control.localEulerAngles = new Vector3(0, angle, 0);
    }
    public void turn_slow(Quaternion rot)
    {
        control.rotation = Quaternion.Lerp(control.rotation, rot, 0.1f);
    }
    public bool try_idle(bool idling)
    {
        is_idle = idling;
        if (animator != null && !is_jumping)
        {
            animator.SetBool("Idling", idling);
            return true;
        }
        else return false;
    }
    public bool try_jump()
    {
        if (animator != null && !is_jumping)
        {
            EffectHandler.cast_effect(transform, EffectHandler.effect.jump);
            animator.SetBool("Jump", true);
            return true;
        }
        else return false;
    }
    public void set_jump_off()
    {
        is_jumping = false;
        animator.SetBool("Jump", is_jumping);
    }
    public void set_stand()
    {
        animator.SetTrigger("Stand");
    }
    public IEnumerator jump_iterator(CharacterController control)
    {
        is_jumping = true;
        float coefficent = 10f;
        Vector3 movement = transform.up;
        if(control.enabled)
            control.Move(movement * coefficent * Time.deltaTime); // cast on air to break isGrounded

        while (control.enabled && !control.isGrounded)
        {
            control.Move(movement * coefficent * Time.deltaTime);
            yield return new WaitForSeconds(0.01f);
            if (coefficent > 0) coefficent -= 0.25f;
            else coefficent -= 0.5f;
            if (coefficent < -50f)
            {
                // too much time spent on air, so die? IDK
                break;
            }
        }
        EffectHandler.cast_effect(transform, EffectHandler.effect.grounded);
        set_jump_off();
        try_idle(is_idle);
        
    }
    public void translate_wakeup()
    {
        int index = 0;
        foreach (Transform child in bone.GetComponentsInChildren<Transform>())
        {
            child.localRotation = Quaternion.Lerp(child.localRotation, original_rot[index], 0.1f);
            child.localPosition = Vector3.MoveTowards(child.localPosition, original_pos[index], 0.01f);
            index++;
        }
    }
    public Transform get_bone()
    {
        return bone;
    }
}
