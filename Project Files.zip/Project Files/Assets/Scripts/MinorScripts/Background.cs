﻿using UnityEngine;

public class Background : MonoBehaviour
{
    Transform moving_slow, moving_fast;

    private void Start()
    {
        moving_slow = this.gameObject.transform.GetChild(1);
        moving_fast = this.gameObject.transform.GetChild(2);
    }

    private void Update()
    {
        moving_slow.Rotate(0, 0, -3f * Time.deltaTime);
        moving_fast.Rotate(0, 0, 10f * Time.deltaTime);
    }
}
