﻿using UnityEngine;
using System;
using System.Collections;
public class TouchHandler
{
    Creator creator;

    bool moving = false;
    int move_id = 0;
    float move_acc = 0f;
    float move_rot = 0f;
    Vector3 move_base;
    Vector3 move_current;

    DateTime start;
    DateTime stop;
    public TouchHandler(Creator creator)
    {
        this.creator = creator;
    }
    public void reset()
    {
        moving = false;
        move_id = 0;
        move_acc = 0f;
        move_rot = 0f;
    }
    public void touch_analyze()
    {
        if (Creator.isMobile)
        {
            //mobile touches
            for (int t = 0; t < Input.touchCount; t++)
            {
                Touch touch = Input.touches[t];
                touch_processor(touch);
            }
        }
        else
        {
            //windows keyboard only works on runner mode 
            if (creator.mode() == Creator.gameMode.runner) keyboard_processor();
        }
    }
    void touch_processor(Touch t)
    {
        int tid = t.fingerId;
        if (t.phase == TouchPhase.Began)
        {
            if (moving && t.fingerId != move_id)
            {
                if (creator.mode() == Creator.gameMode.runner)
                    creator.getPlayer().set_jump();
            }
            start = DateTime.Now;
            if (!moving)
            {
                move_id = t.fingerId;
                move_base = t.position;
                move_current = t.position;
                move_acc = 2.5f;
                moving = true;
            }
        }
        else if (t.phase == TouchPhase.Ended) // check if movement or camera movement is stopped
        {
            stop = DateTime.Now;
            if ((stop - start).TotalMilliseconds <= 333)
            {
                if (creator.mode() == Creator.gameMode.runner)
                    creator.getPlayer().set_jump();
            }
            if (moving && t.fingerId == move_id)
            {
                moving = false;
            }
        }
        else // check active touches
        {
            if (moving && t.fingerId == move_id)
            {
                move_current = t.position;
                if(creator.mode() == Creator.gameMode.runner)
                {
                    creator.getPlayer().move(move_base, move_current, move_acc);
                    if (move_acc < 10f) move_acc += 0.25f;
                }
            }
        }
    }

    void keyboard_processor()
    {
        if (Input.GetKeyDown(KeyCode.Space)) creator.getPlayer().set_jump();
        if (move_rot > 0) move_rot -= 1f;
        else if (move_rot < 0) move_rot += 1f;
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            move_acc = 2.5f;
        }
        else if (Input.GetKeyUp(KeyCode.UpArrow))
        {
            moving = false;
        }
        else if (Input.GetKey(KeyCode.UpArrow))
        {
            moving = true;
            creator.getPlayer().move(Vector3.zero, new Vector3(move_rot, 100, 0), move_acc);
            if (move_acc < 10f) move_acc += 0.25f;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            creator.getPlayer().move(Vector3.zero, new Vector3(move_rot, 100, 0), 0f);
            if (move_rot > -250f) move_rot -= 7.5f;
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            creator.getPlayer().move(Vector3.zero, new Vector3(move_rot, 100, 0), 0f);
            if (move_rot < 250f) move_rot += 7.5f;
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            moving = true;
            creator.getPlayer().move(Vector3.zero, new Vector3(0, -100, 0), move_acc);
            move_rot = 0;
            if (move_acc < 10f) move_acc += 0.25f;
        }
        else if (Input.GetKeyUp(KeyCode.DownArrow))
        {
            moving = false;
        }
        if (Input.GetKey(KeyCode.P))
        {
            creator.getStage().finishStage();
        }
        if (Input.GetKey(KeyCode.O))
        {
            creator.endStage();
        }
        if (Input.GetKey(KeyCode.H))
        {
            creator.getPlayer().hit(false, 3f, creator.transform);
        }
    }
    public bool isMoving()
    {
        return moving;
    }
}