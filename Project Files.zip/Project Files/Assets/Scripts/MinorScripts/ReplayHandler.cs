﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class ReplayHandler : MonoBehaviour
{
    Creator creator;
    Transform camholder;
    Camera cam;

    Button replay;
    Image replay_img;

    RawImage ri;
    RenderTexture rt;

    public void build(Creator creator)
    {
        this.creator = creator;
        camholder = creator.getStage().transform.GetChild(2);
        cam = camholder.GetChild(0).gameObject.GetComponent<Camera>();
        replay = transform.GetChild(0).GetChild(1).gameObject.GetComponent<Button>();
        replay_img = replay.gameObject.transform.GetChild(0).gameObject.GetComponent<Image>();
        replay.onClick.AddListener(() => creator.Menu());
        StartCoroutine(replay_img_iterator());

        rt = new RenderTexture(512, 512, 16, RenderTextureFormat.ARGB32);
        rt.Create();

        cam.targetTexture = rt;

        ri = transform.GetChild(2).GetChild(0).GetChild(0).gameObject.GetComponent<RawImage>();
        ri.texture = rt;

        if(Creator.latest_canvas != null)
        {
            Texture2D paint = Creator.latest_canvas;
            creator.getStage().transform.GetChild(1).gameObject.GetComponent<SpriteRenderer>().sprite =
                Sprite.Create(paint, new Rect(0.0f, 0.0f, paint.width, paint.height), new Vector2(0.5f, 0.5f), 100.0f);
        }

        creator.getGUI().set_bar(" Ranking : " + Creator.latest_rank + "\n Painting : " + Creator.latest_canvas_percent.ToString() + "%\n Time : " + Creator.latest_time.ToString() + "s");
    }

    private void Update()
    {
        if(creator.mode() == Creator.gameMode.replay)
        {
            camholder.Rotate(0, 25f * Time.deltaTime, 0);
        }
    }
    IEnumerator replay_img_iterator()
    {
        float width_factor = replay_img.sprite.texture.width / 100f;
        float height_factor = replay_img.sprite.texture.height / 100f;
        float time_factor = 0.015f;
        yield return new WaitUntil(() => creator.mode() == Creator.gameMode.replay);
        while(creator.mode() == Creator.gameMode.replay)
        {
            for (int j = 0; j < 25; j++)
            {
                replay_img.rectTransform.sizeDelta = new Vector2(replay_img.rectTransform.sizeDelta.x + width_factor,
                    replay_img.rectTransform.sizeDelta.y + height_factor);

                yield return new WaitForSeconds(time_factor);
            }
            for (int j = 0; j < 25; j++)
            {
                replay_img.rectTransform.sizeDelta = new Vector2(replay_img.rectTransform.sizeDelta.x - width_factor,
                    replay_img.rectTransform.sizeDelta.y - height_factor);

                yield return new WaitForSeconds(time_factor);
            }
        }
    }
}
