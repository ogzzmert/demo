﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

static class EffectHandler
{
    static List<Sprite[]> effects;
    static Creator creator;

    static GameObject effect_base;
    public static void build(Creator c)
    {
        creator = c;
        effect_base = Resources.Load("character/Effect") as GameObject;
        effects = new List<Sprite[]>();
        loadSpriteList();
    }

    static void loadSpriteList()
    {
        int effect_counter = 0;
        int sprite_counter = 0;
        bool exit = false;
        bool stop = false;
        List<Sprite> sprites = new List<Sprite>();
        while (!exit)
        {
            sprite_counter = 0;
            sprites.Clear();
            stop = false;
            while (!stop)
            {
                string filename = effect_counter.ToString() + "_" + sprite_counter.ToString();
                var list_file = Resources.Load<Sprite>("textures/effects/" + filename);
                if (list_file != null)
                {
                    sprites.Add(list_file as Sprite);
                    sprite_counter++;
                }
                else stop = true;
            }
            if (sprite_counter == 0) exit = true;
            else
            {
                effects.Add(sprites.ToArray());
                effect_counter++;
            }
        }
    }

    public static void cast_effect(Transform obj, effect effect_type)
    {
        GameObject e = creator.spawn(effect_base);
        e.transform.position = obj.position;

        creator.StartCoroutine(cast_effect_iterator(obj, e.transform, effect_type));
    }
    static IEnumerator cast_effect_iterator(Transform obj, Transform eff, effect effect_type)
    {
        Sprite[] array = effects[(int)effect_type];
        SpriteRenderer s = eff.GetChild(0).gameObject.GetComponent<SpriteRenderer>();

        Transform cam = Creator.main_camera;
        if (cam != null) cam = cam.transform.GetChild(0);

        Color c = new Color(1, 1, 1, 1);
        float fade = 1f / (3 * array.Length);
        for(int i=0; i<array.Length; i++)
        {
            if(s != null)
            {
                s.sprite = array[i];
                for (int j = 0; j < 3; j++)
                {
                    c.a -= fade;
                    if(s != null) s.color = c;
                    if (cam != null) s.transform.LookAt(cam);
                    yield return new WaitForSeconds(0.02f);
                }
            }

        }
        if(eff != null) creator.destroyThis(eff.gameObject);
    }
    public enum effect{
        jump = 0,
        hit = 1,
        grounded = 2,
        smack = 3
    }
}

