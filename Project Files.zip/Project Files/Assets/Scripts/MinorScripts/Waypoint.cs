﻿using UnityEngine;

public class Waypoint : MonoBehaviour
{
    public point waypoint = point.normal; // waypoint type
    public float radius = 1f;  // tolerance of reaching point

    Vector3[] pose;  // sub-waypoint list
    int alternates = 0; // amount of sub-waypoints

    private void Start()
    {
        alternates = this.gameObject.transform.childCount;
        pose = new Vector3[alternates];
        for(int i = 0; i < alternates; i++)
        {
            pose[i] = this.gameObject.transform.GetChild(i).position;
        }
    }
    public Vector3 get_pose(float seed)
    {
        int value = (int)(seed * 10f) % alternates;
        return pose[value];
    }
    public enum point
    {
        normal = 0,
        jump = 1,
        narrow = 2
    }
}
