﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class MenuHandler : MonoBehaviour
{
    Creator creator;
    Transform camholder;
    Camera cam;

    Button play;
    Image play_img;

    RawImage ri;
    RenderTexture rt;

    Transform[] ragdolls;
    public void build(Creator creator)
    {
        this.creator = creator;
        camholder = creator.getStage().transform.GetChild(1);
        cam = camholder.GetChild(0).gameObject.GetComponent<Camera>();
        play = transform.GetChild(3).GetChild(0).gameObject.GetComponent<Button>();
        play_img = play.gameObject.transform.GetChild(0).gameObject.GetComponent<Image>();
        StartCoroutine(play_img_iterator());

        rt = new RenderTexture(512, 512, 16, RenderTextureFormat.ARGB32);
        rt.Create();

        cam.targetTexture = rt;

        ri = transform.GetChild(2).GetChild(0).GetChild(0).gameObject.GetComponent<RawImage>();
        ri.texture = rt;

        Transform content = creator.getStage().transform.GetChild(0).GetChild(0);
        ragdolls = new Transform[content.childCount];
        for(int i = 0; i < content.childCount; i++)
        {
            ragdolls[i] = content.GetChild(i).GetChild(0).GetChild(1).GetChild(0);
        }
        StartCoroutine(ragdoll_checker());
    }
    IEnumerator ragdoll_checker()
    {
        Physics.gravity = new Vector3(0, -3, 0);
        play.gameObject.SetActive(false);
        yield return new WaitForSeconds(1f);
        play.gameObject.SetActive(true);
        play.onClick.AddListener(() => creator.Stage(0));

        yield return new WaitUntil(() => creator.mode() == Creator.gameMode.menu);
        while (creator.mode() == Creator.gameMode.menu)
        {
            foreach(Transform ragdoll in ragdolls)
            {
                float dist = Vector3.Distance(Vector3.zero, ragdoll.localPosition);
                if (dist > 0.33f)
                {
                    foreach (Rigidbody child in ragdoll.GetComponentsInChildren<Rigidbody>())
                    {
                        child.isKinematic = true;
                    }
                        ragdoll.localPosition = Vector3.zero;
                    foreach (Rigidbody child in ragdoll.GetComponentsInChildren<Rigidbody>())
                    {
                        child.isKinematic = false;
                    }

                }
            }
            yield return new WaitForSeconds(0.5f);
        }
    }
    IEnumerator play_img_iterator()
    {
        float width_factor = play_img.sprite.texture.width / 100f;
        float height_factor = play_img.sprite.texture.height / 100f;
        float time_factor = 0.015f;
        yield return new WaitUntil(() => creator.mode() == Creator.gameMode.menu);
        while (creator.mode() == Creator.gameMode.menu)
        {
            for (int j = 0; j < 25; j++)
            {
                play_img.rectTransform.sizeDelta = new Vector2(play_img.rectTransform.sizeDelta.x + width_factor,
                    play_img.rectTransform.sizeDelta.y + height_factor);

                yield return new WaitForSeconds(time_factor);
            }
            for (int j = 0; j < 25; j++)
            {
                play_img.rectTransform.sizeDelta = new Vector2(play_img.rectTransform.sizeDelta.x - width_factor,
                    play_img.rectTransform.sizeDelta.y - height_factor);

                yield return new WaitForSeconds(time_factor);
            }
        }
    }
}
