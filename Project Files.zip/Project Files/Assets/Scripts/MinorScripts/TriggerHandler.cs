﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerHandler : MonoBehaviour
{
    Creator creator;
    Vector3 pose; // starting position
    bool ready = false;
    Vector3 move; // moving direction if any
    Transform movable; // moving part of the object
    Transform interactable; // object that interacts with the target or player, can be harmful or harmless

    public role job; // objective : kill, push, finish the race etc.
    public action act; // behaviour : rotator, stick, donut, horizontan obstacle, balloon etc.
    public bool reversed = false; // if object movement is reversed
    public float stun_time = 3f; // ragdoll time for harmfull objects
    private void Start()
    {
        ready = false;
        StartCoroutine(build());
    }
    private void OnTriggerEnter(Collider other)
    {
        if (ready && Creator.isWorldReady())
        {
            string tag = other.gameObject.tag;
            if (tag == "PlayerModel")
            {
                if (job == role.kill) creator.getPlayer().hit(true, stun_time, interactable);
                else if (job == role.push) creator.getPlayer().hit(false, stun_time, interactable);
                else if (job == role.finish) creator.getStage().finishStage();
                else if (act == action.balloon) thrown_by(creator.getPlayer().getPosition());
                
            }
            else if (tag == "TargetModel")
            {
                TargetManager t = other.gameObject.transform.parent.parent.gameObject.GetComponent<TargetManager>();
                if (job == role.kill) t.hit(true, stun_time, interactable);
                else if (job == role.push) t.hit(false, stun_time, interactable);
                else if (job == role.finish) t.finish();
                else if (act == action.balloon) thrown_by(t.getPosition());
            }
            else if (tag == "TargetDetector")
            {
                TargetManager t = other.gameObject.transform.parent.parent.gameObject.GetComponent<TargetManager>();

                if (job == role.kill)
                { if (act == action.horizontal || act == action.donut) t.walk_away(interactable); }
                else if (act == action.rotator) t.jump_over(pose);
            }
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (ready && Creator.isWorldReady())
        {
            string tag = other.gameObject.tag;
            string this_tag = gameObject.tag;
            if (tag == "PlayerModel")
            {
                if (act == action.rotating_platform)
                {
                    float factor = 1f;
                    if (reversed) factor *= -1f;
                    creator.getPlayer().push(interactable.right * factor, 10f);
                } 
            }
            else if (tag == "TargetModel")
            {
                TargetManager t = other.gameObject.transform.parent.parent.gameObject.GetComponent<TargetManager>();

                if (t != null && act == action.rotating_platform)
                {
                    float factor = 1f;
                    if (reversed) factor *= -1f;
                    t.push(interactable.right * factor, 5f);
                }
            }
        }
    }
    IEnumerator build()
    {
        yield return new WaitUntil(() => Creator.isWorldReady());
        creator = gameObject.transform.root.gameObject.GetComponent<Creator>();
        movable = this.gameObject.transform;
        interactable = movable;
        pose = interactable.position;
        // init moving objects
        yield return new WaitForSeconds(1f);
        if(act == action.horizontal) StartCoroutine(horizontal());
        else if (act == action.donut) StartCoroutine(donut());
        else if (act == action.rotating_platform) StartCoroutine(rotating_platform());
        else if (act == action.rotator) StartCoroutine(rotator());
        ready = true;
    }
    IEnumerator horizontal()
    {
        float position = Vector3.Distance(pose, this.gameObject.transform.position);
        Vector3 pose_a = this.gameObject.transform.GetChild(0).position;
        Vector3 pose_b = this.gameObject.transform.position;
        Vector3 pose_c = pose_a;
        float push = 10f;
        while (Creator.isWorldReady())
        {
            Vector3 direction = (pose_c - interactable.position).normalized;
            move = direction * push * Time.deltaTime;

            yield return new WaitForSeconds(0.1f);
            position = Vector3.Distance(pose_c, interactable.position);
            if (position < 1f)
            {
                if (pose_c == pose_a) pose_c = pose_b;
                else pose_c = pose_a;
            }
        }
    }
    IEnumerator donut()
    {
        float push = 5f;
        movable = movable.parent;
        if (reversed) push *= -1f;
        float position = Vector3.Distance(pose, interactable.position);
        Vector3 pose_a = movable.parent.GetChild(2).position;
        Vector3 pose_b = movable.parent.GetChild(3).position;
        Vector3 pose_c = pose_a;
        while (Creator.isWorldReady())
        {
            Vector3 direction = (pose_c - interactable.position);
            move = direction * push * Time.deltaTime;

            yield return new WaitForSeconds(0.1f);
            position = Vector3.Distance(pose_c, interactable.position);
            if (position < 1f)
            {
                if (pose_c == pose_a) pose_c = pose_b;
                else pose_c = pose_a;

                move = Vector3.zero;
                yield return new WaitForSeconds(creator.rand(0.2f, 1f));
            }
        }

    }
    IEnumerator rotating_platform()
    {
        float push = 25f;
        if (reversed) push *= -1f;
        while (Creator.isWorldReady())
        {
            movable.Rotate(0,0, push * Time.deltaTime);
            yield return new WaitForSeconds(0.015f);
        }

    }
    IEnumerator rotator()
    {
        float push = 60f;
        if (reversed) push *= -1f;
        movable = movable.parent.parent;
        while (Creator.isWorldReady())
        {
            movable.Rotate(0, push * Time.deltaTime, 0);
            yield return new WaitForSeconds(0.015f);
        }

    }
    void Update()
    {
        if(move != Vector3.zero)
        {
            movable.Translate(move, this.transform);
        }
    }
    void thrown_by(Vector3 sender)
    {
        EffectHandler.cast_effect(interactable, EffectHandler.effect.hit);
        StartCoroutine(thrown_by_iterator(sender));  
    }
    IEnumerator thrown_by_iterator(Vector3 sender)
    {
        Rigidbody r = GetComponent<Rigidbody>();

        float accel = 1f;
        for (int i = 0; i < 20; i++)
        {
            if(r != null)
            {
                r.MovePosition(((interactable.position - sender).normalized * accel) + interactable.position);
                accel -= 0.05f;
                yield return new WaitForSeconds(0.015f);
            }
        }
        

    }
    public enum role
    {
        none = 0,
        kill = 1,
        push = 2,
        finish = 3
    }
    public enum action
    {
        none = 0,
        horizontal = 1,
        donut = 2,
        rotating_platform = 3,
        rotator = 4,
        balloon = 5
    }
}
