﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class RagdollHandler : MonoBehaviour
{
    Creator creator;
    Rigidbody doll;

    CharacterController control;

    Transform bone;

    Vector3 direction = Vector3.zero;
    float speed = 10f;

    bool is_active = false;
    public void build(Creator creator, CharacterController control)
    {
        this.creator = creator;
        this.control = control;
        bone = transform.GetChild(1);
        doll = this.gameObject.transform.GetChild(1).GetChild(0).gameObject.GetComponent<Rigidbody>();

        this.gameObject.SetActive(false);
    }
    public IEnumerator turn_on(Transform interactable)
    {
        direction = (interactable.transform.position - control.transform.position).normalized;
        yield return new WaitForSeconds(0.25f);
        speed = 10f;
        is_active = true;
        doll.constraints = RigidbodyConstraints.None;
    }
    public IEnumerator turn_off()
    {
        control.transform.position = doll.gameObject.transform.position;
        doll.gameObject.transform.localPosition = Vector3.zero;
        is_active = false;
        yield return new WaitForSeconds(0.01f);
        doll.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ;
    }
    private void Update()
    {
        if (is_active)
        {
            Vector3 old = doll.gameObject.transform.position;
            control.transform.position = Vector3.MoveTowards(control.transform.position, old, 0.1f);
            doll.gameObject.transform.position = old;
            doll.gameObject.transform.Translate(direction * speed * Time.deltaTime);
            if (speed > 0) speed -= 1f;
        }
    }
    public Transform get_bone()
    {
        return bone;
    }
}
