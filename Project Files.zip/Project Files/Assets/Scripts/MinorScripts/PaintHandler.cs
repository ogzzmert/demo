﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PaintHandler : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    Creator creator;
    Texture2D paint;
    Texture2D brush;
    SpriteRenderer sprite_renderer;
    Vector2 brush_pose;

    color current_color_code;
    Color current_color;

    Button[] buckets;
    Button done;

    Transform[] bucket_obj;
    Transform brush_obj;
    float brush_angle;

    float x_pad, x_fac, y_pad, y_fac;
    int brush_x, brush_y;
    float[] corners = new float[4];

    bool ready = false;
    bool down = false;
    int bar_percentage = 0;
    int percentage = 0;
    public void build(Creator creator)
    {
        this.creator = creator;
        ready = false;
        StartCoroutine(generate_level());
        StartCoroutine(checker());
        creator.getGUI().throw_warning(GuiManager.warning.to_paint, 7f);
    }
    public void OnPointerUp(PointerEventData data)
    {
        down = false;
    }
    public void OnPointerDown(PointerEventData data)
    {
        down = true;
    }
    IEnumerator checker()
    {
        // this endless loop will rotate brush and calculate percentage of painted surface
        Vector2 pose1 = Vector2.zero;
        Vector2 pose2 = Vector2.zero;
        Vector2 pose = new Vector2(0, 1);
        yield return new WaitUntil(() => Creator.isWorldReady() && creator.mode() == Creator.gameMode.paint && ready);
        bool tick = true;
        while (Creator.isWorldReady() && creator.mode() == Creator.gameMode.paint && ready)
        {
            if (down) pose1 = get_position();
            
            yield return new WaitForSeconds(0.1f);
            if (down)
            {
                // this section rotates brush
                pose2 = get_position();
                float dis = Vector2.Distance(pose1, pose2);
                if(dis > 15f)
                {
                    Vector2 dir = (pose2 - pose1).normalized;
                    if (pose2.x < pose1.x) dir *= -1;
                    brush_angle = Vector2.Angle(pose, dir);
                    brush = rotateTexture(Creator.resource_paintbrush, brush_angle + 90);
                }

            }

            if (tick)
            {
                // this section calculates percentage of painted surface
                float current = 0;
                Color32[] c = paint.GetPixels32();
                for (int i = 0; i < c.Length; i++)
                {
                    current += c[i].a;
                }
                percentage = (int)(current * 100 / (512 * 512 * 255f));
                tick = false;
            }
            else tick = true;

            if (percentage != 0 && bar_percentage == 0 && !done.gameObject.activeSelf) done.gameObject.SetActive(true);

            if (bar_percentage < percentage) bar_percentage++;
            if(ready) creator.getGUI().set_bar("%" + bar_percentage.ToString());
            
        }
    }
    Vector2 get_position()
    {
        if (down)
        {
            if (Creator.isMobile) return Input.GetTouch(0).position;
            else return Input.mousePosition;
        }
        else return Vector2.zero;
    }
    private void Update()
    {
        if (ready && down)
        {
            check_brush();
        }
        move_buckets();
    }
    void check_brush()
    {
        brush_pose = (get_position() / Screen.width) * 720f;

        if (brush_pose.x > corners[0] && brush_pose.x < corners[1])
        {
            if (brush_pose.y > corners[2] && brush_pose.y < corners[3])
            {
                brush_x = (int)(corners[1] - brush_pose.x);
                brush_y = (int)(brush_pose.y - corners[2]);
                update_canvas(brush_x, brush_y);
            }
        }
    }
    void update_canvas(int x, int y)
    {
        for(int i=-48; i<=48; i++)
        {
            for(int j=-48; j<=48; j++)
            {
                if(x + i >= 0 && y + j >= 0 && x + i < 512 && y + j < 512)
                {
                    Color c = brush.GetPixel(i+48, j+48);
                    if(c.a > 0.05f) paint.SetPixel(x + i, y + j,
                        new Color(current_color.r, current_color.g, current_color.b, c.a/2.5f  + paint.GetPixel(x + i, y + j).a));
                }
            }
        }

        paint.Apply();
        sprite_renderer.material.SetTexture("_MainTex", paint);

        // set 3d brush angle and position
        brush_obj.localPosition = new Vector3(brush_x * x_fac - x_pad, y_pad + brush_y * y_fac, brush_obj.localPosition.z);
        float angle = brush_angle;
        if (angle > 90) angle -= 180;

        brush_obj.localEulerAngles = new Vector3(-45, - angle, angle); // change later
    } 
    IEnumerator generate_level()
    {
        // use sprite renderer object to paint, texture is painted and reflected on spriterenderer object over time
        yield return new WaitUntil(() => creator.mode() == Creator.gameMode.paint);
        brush_obj = creator.getStage().transform.GetChild(0).GetChild(4).GetChild(0);
        Vector3 min = brush_obj.parent.GetChild(1).localPosition;
        Vector3 max = brush_obj.parent.GetChild(2).localPosition;
        x_pad = -max.x; y_pad = max.y; x_fac = (min.x - max.x) / 512f; y_fac = (min.y - max.y) / 512f; ;
        // x_pad = 3.1f; y_pad = -5.8f; x_fac = 0.0085f; y_fac = 0.0085f;

        brush = Creator.resource_paintbrush;
        sprite_renderer = creator.getCanvas();


        Transform bucket = creator.getGUI().transform.GetChild(0).GetChild(2);
        Transform bucket_obj_list = creator.getStage().transform.GetChild(0).GetChild(3);
        buckets = new Button[bucket.childCount];
        bucket_obj = new Transform[bucket.childCount];
        for(int i = 0; i < bucket.childCount; i++)
        {
            int index = i;
            buckets[i] = bucket.GetChild(i).gameObject.GetComponent<Button>();
            buckets[i].onClick.AddListener(() => set_color((color)index));
            bucket_obj[i] = bucket_obj_list.GetChild(i).GetChild(0);
        }
        done = creator.getGUI().transform.GetChild(0).GetChild(1).gameObject.GetComponent<Button>();
        done.onClick.AddListener(complete_painting);
        done.gameObject.SetActive(false);

        paint = new Texture2D(512, 512);

        for (int x = 0; x < paint.height; x++)
        {
            for (int y = 0; y < paint.width; y++)
            {
                paint.SetPixel(x, y, new Color(0,0,0,0));
            }
        }
        paint.filterMode = FilterMode.Point;
        paint.Apply();
        sprite_renderer.sprite = Sprite.Create(paint, new Rect(0.0f, 0.0f, paint.width, paint.height), new Vector2(0.5f, 0.5f), 100.0f);

        RectTransform rt = gameObject.GetComponent<RectTransform>();
        Vector2 rtp = (rt.position / Screen.width) * 720f;
        corners[0] = (rtp.x + rt.rect.xMin);
        corners[1] = (rtp.x + rt.rect.xMax);
        corners[2] = (rtp.y + rt.rect.yMin);
        corners[3] = (rtp.y + rt.rect.yMax);
        set_color(color.red);
        ready = true;
    }
    void complete_painting()
    {
        StartCoroutine(complete_painting_iterator());
    }
    IEnumerator complete_painting_iterator()
    {
        // redirect to reply menu after ranking the painting
        done.gameObject.SetActive(false);
        ready = false;
        if (percentage <= 50) creator.getGUI().throw_warning(GuiManager.warning.praise_1, 2.5f, 2, 2);
        else if (percentage <= 99) creator.getGUI().throw_warning(GuiManager.warning.praise_2, 2.5f, 2, 2);
        else creator.getGUI().throw_warning(GuiManager.warning.praise_3, 2.5f, 2, 2);
        yield return new WaitForSeconds(2f);
        Creator.latest_canvas_percent = percentage;
        Creator.latest_canvas = paint;
        creator.endStage();
    }
    public enum color
    {
        blue = 0,
        red = 1,
        yellow = 2
    }
    void set_color(color c)
    {
        // set desired color code, change 3d brush, do animation for selected bucket
        current_color_code = c;
        if (c == color.blue) current_color = new Color(0.65f, 0.65f, 1);
        else if (c == color.red) current_color = new Color(1, 0.25f, 0.25f);
        else if (c == color.yellow) current_color = new Color(1, 1, 0.25f);

        Transform brushes = brush_obj;
        for (int i = 0; i < brushes.childCount - 1; i++)
        {
            if (i != (int)c) brushes.GetChild(i).gameObject.SetActive(false);
            else brushes.GetChild(i).gameObject.SetActive(true);
        }
        StartCoroutine(zoom_bucket());
    }
    IEnumerator zoom_bucket()
    {
        // ez animation for selected bucket
        int bucket_id = (int)current_color_code;
        if (ready)
        {
            bucket_obj[bucket_id].transform.localScale = new Vector3(1, 1, 1);
            for (int j = 0; j < 5; j++)
            {
                bucket_obj[bucket_id].localScale = 
                    new Vector3(bucket_obj[bucket_id].localScale.x + 0.1f, bucket_obj[bucket_id].localScale.y + 0.1f, bucket_obj[bucket_id].localScale.z + 0.1f);
                yield return new WaitForSeconds(0.015f);
            }
            for (int j = 0; j < 5; j++)
            {
                bucket_obj[bucket_id].localScale =
                    new Vector3(bucket_obj[bucket_id].localScale.x - 0.1f, bucket_obj[bucket_id].localScale.y - 0.1f, bucket_obj[bucket_id].localScale.z - 0.1f);
                yield return new WaitForSeconds(0.015f);
            }
            bucket_obj[bucket_id].transform.localScale = new Vector3(1, 1, 1);
        }
    }
    void move_buckets()
    {
        if (ready)
        {
            for (int j = 0; j < bucket_obj.Length; j++)
            {
                // move buckets here, nothing serious
                bucket_obj[j].transform.Rotate(Vector3.up, 0.5f);
            }
        }
    }
    // messy mathematical calculations below
    Texture2D rotateTexture(Texture2D tex, float angle)
    {
        // calculate rotated texture
        Texture2D rotImage = new Texture2D(tex.width, tex.height);
        int x, y;
        float x1, y1, x2, y2;

        int w = tex.width;
        int h = tex.height;
        float x0 = rot_x(angle, -w / 2.0f, -h / 2.0f) + w / 2.0f;
        float y0 = rot_y(angle, -w / 2.0f, -h / 2.0f) + h / 2.0f;

        float dx_x = rot_x(angle, 1.0f, 0.0f);
        float dx_y = rot_y(angle, 1.0f, 0.0f);
        float dy_x = rot_x(angle, 0.0f, 1.0f);
        float dy_y = rot_y(angle, 0.0f, 1.0f);

        x1 = x0;
        y1 = y0;

        for (x = 0; x < tex.width; x++)
        {
            x2 = x1;
            y2 = y1;
            for (y = 0; y < tex.height; y++)
            {       
                x2 += dx_x;
                y2 += dx_y;
                rotImage.SetPixel((int)Mathf.Floor(x), (int)Mathf.Floor(y), getPixel(tex, x2, y2));
            }
            x1 += dy_x;
            y1 += dy_y;

        }
        rotImage.Apply();
        return rotImage;
    }
    private Color getPixel(Texture2D tex, float x, float y)
    {
        Color pix;
        int x1 = (int)Mathf.Floor(x);
        int y1 = (int)Mathf.Floor(y);
        if (x1 > tex.width || x1 < 0 ||  y1 > tex.height || y1 < 0) pix = Color.clear;
        else pix = tex.GetPixel(x1, y1);
        return pix;
    }
    private float rot_x(float angle, float x, float y)
    {
        float cos = Mathf.Cos(angle / 180.0f * Mathf.PI);
        float sin = Mathf.Sin(angle / 180.0f * Mathf.PI);
        return (x * cos + y * (-sin));
    }
    private float rot_y(float angle, float x, float y)
    {
        float cos = Mathf.Cos(angle / 180.0f * Mathf.PI);
        float sin = Mathf.Sin(angle / 180.0f * Mathf.PI);
        return (x * sin + y * cos);
    }
}